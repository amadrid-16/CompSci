public class Color{
   public int r;
   public int g;
   public int b;
   public int rin;
   public int gin;
   public int bin;
   public int decform;
   public int redChange;
   public int greenChange;
   public int blueChange;
   int saturation;
   int compareVal;
   public String hexform;
   public static String hexString;
   public String rgb;
   public static int validNum;
   
   
   public String toString(){
      this.rgb = "rgb(" + this.r + ", " + this.g + ", " + this.b + ")";
   
      return this.rgb;
   }
   public Color(){
      this(255,255,255);//set defaults

      //then run rgb method
   }
   public Color(int rin, int gin, int bin){
      this.r = Color.valid(rin);//for rgb input
      this.g = Color.valid(gin);
      this.b = Color.valid(bin);
      
     
      
   }
   public String htmlHex(){
      //convert from rgb to hex
      this.decform = (((r*256)+g)*256)+b;
         //rin * 256
         //^^+g
         //^^*256
         //^^+b
         //^^=decimal
      //decimal to hexadecimal
      this.hexform = Integer.toHexString(this.decform);
      this.hexform = "#" + this.hexform.toUpperCase(); 
      return this.hexform;//Hexadecimal 
   }
   public int changeRed(int redChange){
      this.r += redChange;
      return r;
   }
   public int changeGreen(int greenChange){
      this.g += greenChange;
      return g;
   }
   public int changeBlue(int blueChange){
      this.b += blueChange;
      return b;
   }
   public static Color black(){
     Color black = new Color(0, 0, 0);
     return black;
   }
   public int saturation(){
      this.saturation = this.r + this.g + this.b;
      return this.saturation;
   }
   public int compareTo(Color other){
      this.compareVal = other.saturation - this.saturation;
      
      return this.compareVal;
   }
   public static String hexify(int num){
      
      hexString = Integer.toHexString(num);
      return hexString;
   }
   public static int valid(int num){
      
     if(num<0){
      validNum = 0;
     } 
     else if(num>255){
      validNum = 255;
     }
     else{
      validNum = num;
     }
     return validNum;
   }


}