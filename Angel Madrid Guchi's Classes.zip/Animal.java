/**
* @assignment make_some_animals
* @description Sample class made by guchi. Animal superclass
* 
* @author Angel Madrid 
* @date 1/30/2015
* 
* @version 1.2
*/
public class Animal {
	public boolean isAlive;
	public String eyeColor;
	public int numLegs;
	public String name;

	public void walk(){
		System.out.println("I'm walking!");
	}
}